<?php

namespace App\Entity;

use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\UserInterface;


/**
 * Auteur
 *
 * @ORM\Table(name="auteur")
 * @ORM\Entity
 *
 * @UniqueEntity(
 *     fields={"identifiant"},
 *     message="Cet identifiant d'auteur est déjà utilisé."
 * )
 */
class Auteur implements UserInterface
{
    /**
     * @var string
     *
     * @ORM\Column(name="identifiant", type="string", length=50, nullable=false)
     * @ORM\Id
     *
     * @Assert\NotBlank(message="Le champ 'identifiant' est obligatoire.")
     * @Assert\Length(
     *     min="3",
     *     max="50",
     *     minMessage="L'identifiant doit faire au moins 3 caractères.",
     *     maxMessage="L'identifiant ne doit pas dépasser 50 caractères."
     * )
     */
    private $identifiant;

    /**
     * @var string
     *
     * @ORM\Column(name="motdepasse", type="string", length=200, nullable=false)
     *
     * @Assert\NotBlank(message="Le champ 'motdepasse' est obligatoire.")
     * @Assert\Length(
     *     min="3",
     *     max="200",
     *     minMessage="Le mot de passe doit faire au moins 3 caractères.",
     *     maxMessage="Le mot de passe ne doit pas dépasser 200 caractères."
     * )
     */
    private $motdepasse;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="string", length=50, nullable=false)
     *
     * @Assert\NotBlank(message="Le champ 'prenom' est obligatoire.")
     * @Assert\Length(
     *     min="3",
     *     max="50",
     *     minMessage="Le prénom doit faire au moins 3 caractères.",
     *     maxMessage="Le prénom ne doit pas dépasser 50 caractères."
     * )
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="string", length=50, nullable=false)
     *
     * @Assert\NotBlank(message="Le champ 'nom' est obligatoire.")
     * @Assert\Length(
     *     min="3",
     *     max="50",
     *     minMessage="Le nom doit faire au moins 3 caractères.",
     *     maxMessage="Le nom ne doit pas dépasser 50 caractères."
     * )
     */
    private $nom;

    public function getIdentifiant(): ?string
    {
        return $this->identifiant;
    }

    public function setIdentifiant(string $identifiant): self
    {
        $this->identifiant = $identifiant;

        return $this;
    }

    public function getMotdepasse(): ?string
    {
        return $this->motdepasse;
    }

    public function setMotdepasse(string $motdepasse): self
    {
        $this->motdepasse = $motdepasse;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }
    
    public function getPassword()
    {
        return $this->motdepasse;
    }

    public function eraseCredentials()
    {}

    public function getSalt()
    {}

    public function getRoles()
    {
        return ['ROLE_AUTEUR'];
    }
    
    public function getUsername()
    {
        return $this->identifiant;
    }


}
