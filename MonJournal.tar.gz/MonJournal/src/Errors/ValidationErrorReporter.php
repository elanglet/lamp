<?php
namespace App\Errors;

use Symfony\Component\HttpFoundation\Response;

class ValidationErrorReporter
{

    public function reportValidationError(object $erreurs): array
    {
        $erreursValidation = [];

        foreach ($erreurs as $e) {
            $err['message'] = $e->getMessage();
            $err['property'] = $e->getPropertyPath();
            $err['value'] = $e->getInvalidValue();
            $erreursValidation[] = $err;
        }

        return $erreursValidation;
    }
}

