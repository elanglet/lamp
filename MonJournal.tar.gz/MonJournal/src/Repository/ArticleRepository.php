<?php


namespace App\Repository;

// Repository personnalisé pour les entités 'Article'. Attention de rajouter sa déclaration dans le mapping de l'entité
// @ORM\Entity(repositoryClass='...')
class ArticleRepository extends \Doctrine\ORM\EntityRepository
{

    public function findTodayDQL() {

        // SQL : SELECT * FROM article WHERE date_publication LIKE '2020-11-04%'

        $dql = "SELECT a FROM App:Article a WHERE a.datePublication LIKE :theDate";

        // On créé la requête DQL
        $query = $this->getEntityManager()->createQuery($dql);

        // On remplace la variable 'theDate' par sa valeur.
        $aujourdhui = date('Y-m-d') . "%";
        $query->setParameter('theDate', $aujourdhui);

        // On récupère et on renvoi les résultats.
        return $query->getResult();

    }

    public function findTodayQB() {

        $aujourdhui = date('Y-m-d') . "%";

        // On créé l'objet QueryBuilder
        $qb = $this->getEntityManager()->createQueryBuilder();

        // On construit la requête (DQL) par utilisation des méthodes du QueryBuilder
        $query = $qb->select('a')
                    ->from('App:Article', 'a')
                    ->where(
                        $qb->expr()->like('a.datePublication', ':theDate')
                    )
                    ->setParameter('theDate', $aujourdhui)
                    ->getQuery();

        return $query->getResult();
    }

}