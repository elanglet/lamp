<?php


namespace App\Model;


use App\Entity\Auteur;
use Doctrine\ORM\EntityManagerInterface;

class AuteurService
{
    private $em;

    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;
    }

    public function ajouterAuteur(Auteur $auteur) {
        try {
            $this->em->persist($auteur);
            $this->em->flush();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la création de l'auteur.", null, $e);
        }
    }

    public function modifierAuteur(Auteur $auteur) {
        try {
            $this->em->persist($auteur);
            $this->em->flush();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur lors de la modification de l'auteur.", null, $e);
        }
    }

    public function rechercherTousLesAuteurs() {
        try {
            return $this->em->getRepository('App:Auteur')->findAll();
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur de récupération de la liste des auteurs.", null, $e);
        }
    }

    public function rechercherAuteurParIdentifiant(string $identifiant) {
        try {
            return $this->em->getRepository('App:Auteur')->find($identifiant);
        }
        catch(\Exception $e) {
            throw new \Exception("Erreur de récupération de l'auteur $identifiant.", null, $e);
        }
    }

}