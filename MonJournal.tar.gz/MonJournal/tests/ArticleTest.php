<?php

namespace App\Tests;

use PHPUnit\Framework\TestCase;

class ArticleTest extends TestCase
{
    public function testSomething()
    {
        $this->assertTrue(true);
    }
}
