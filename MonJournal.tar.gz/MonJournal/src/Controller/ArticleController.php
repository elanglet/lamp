<?php

namespace App\Controller;

use App\Entity\Article;
use App\Entity\Auteur;
use App\Form\ArticleType;
use App\Model\ArticleService;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ArticleController extends AbstractController
{
    /**
     * @Route("/article/tous", name="article_tous")
     */
    public function tous(ArticleService $articleService): Response
    {
        // Invocation du modèle pour récupérer les données
        $tousLesArticles = $articleService->rechercherTousLesArticles();
        $articlesDuJour = $articleService->rechercherArticlesDuJour();

        

        return $this->render(
            'article/tous.html.twig',
            [
                'tousLesArticles' => $tousLesArticles,
                'articlesDuJour' => $articlesDuJour
            ]
        );
    }

    /**
     * @Route("/article/lire/{id}", name="article_lire", requirements={"id"="\d+"})
     */
    public function lire($id, ArticleService $articleService): Response
    {
        $article = $articleService->rechercherArticleParId($id);

        return $this->render(
            'article/lire.html.twig',
            [ 'article' => $article ]
        );
    }

    /**
     * @Route("/article/creer", name="article_creer")
     */
    public function creer(ArticleService $articleService, Request $request): Response
    {
        // 1. Création de l'entité à remplir avec le formulaire.
        $article = new Article();

        // Définir la valeur par défaut de la date :
        $date = \DateTime::createFromFormat("Y-m-d H:i:s", date("Y-m-d H:i:s"));
        $article->setDatePublication($date);

        // 2. Création du formulaire via la classe de formulaire, et association de l'entité.
        $form = $this->createForm(
            ArticleType::class,         // Le type de formulaire
            $article                         // L'objet du modèle associé
        );

        // 3. Traitement de la requete - L'objet 'Symfony\Component\HttpFoundation\Request' doit être injecté en tant que paramètre de la méthode.
        $form->handleRequest($request);

        // 4. Test pour savoir si le formulaire doit être affiché ou soumis
        if($form->isSubmitted() && $form->isValid()) {
            // POST

            // On ajoute l'article qui à été alimenté avec les données du formulaire !
            $articleService->ajouterArticle($article);

            // On redirige vers la page d'affichage de l'article...
            return $this->redirect(
                $this->generateUrl('article_lire', ['id' => $article->getId()])
            );
        }
        else {
            // GET

            // Rendu du template en transmettant l'objet de formulaire
            return $this->render(
                'article/creer.html.twig',
                [ 'ajouterForm' => $form->createView() ]
            );
        }
    }

    /**
     * @Route(
     *     "/article/modifier/{id}",
     *     name="article_modifier",
     *     requirements={"id"="\d+"}
     * )
     */
    public function modifier($id, ArticleService $articleService, Request $request): Response
    {
        $article = $articleService->rechercherArticleParId($id);

        $form = $this->createForm(
            ArticleType::class,         // Le type de formulaire
            $article                         // L'objet du modèle associé
        );
        $form->remove('datePublication');
        $form->remove('auteur');

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()) {
            $articleService->modifierArticle($article);
            return $this->redirect($this->generateUrl('article_lire', ['id' => $article->getId()]));
        }
        else {
            return $this->render(
                'article/modifier.html.twig',
                [ 'modifierForm' => $form->createView() ]
            );
        }
    }

    /**
     * @Route("/article/supprimer/{id}", name="article_supprimer", requirements={"id"="\d+"})
     */
    public function supprimer($id, ArticleService $articleService): Response
    {
        $articleService->supprimerArticle($id);

        $this->addFlash('suppression', "Article supprimé !!!");

        return $this->redirect(
            $this->generateUrl('accueil')
        );
    }
}
