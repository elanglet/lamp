<?php

namespace App\Tests;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ArticleControllerTest extends WebTestCase
{

    private static $client;

    public static function setUpBeforeClass()
    {
        echo "setUpBeforeClass\n";

        self::$client = static::createClient([], ['HTTP_HOST' => 'monjournal.formation.fr']);
    }

    public function setUp() {
        echo "SetUp\n";
    }

    public function testAccueil()
    {
        echo "testAccueil\n";

        $crawler = self::$client->request('GET', '/');

        $this->assertResponseIsSuccessful();
        $this->assertSelectorTextContains('h1', 'Bienvenue sur MonJournal !', "Erreur dans le titre H1");
    }

    public function testLireArticle1() {
        echo "testLireArticle1\n    ";

        $this->assertTrue(true);
    }
}
