<?php

namespace App\Controller;

use App\Entity\Article;
use App\Entity\Auteur;
use App\Form\ArticleType;
use App\Model\ArticleService;
use App\Model\AuteurService;
use JMS\Serializer\SerializerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Validator\Validator\ValidatorInterface;
use App\Errors\ValidationErrorReporter;

class ArticleRestController extends AbstractController
{
    
    private $articleService;
    private $serializer;
    private $validator;
    private $reporter;
    
    public function __construct(ArticleService $articleService, SerializerInterface $serializer, ValidatorInterface $validator, ValidationErrorReporter $reporter) {
        $this->articleService = $articleService;
        $this->serializer = $serializer;
        $this->validator = $validator;
        $this->reporter = $reporter;
    }
    
    /**
     * @Route(
     *      "/api/articles", 
     *      name="api_article_tous", 
     *      methods={"GET"}
     * )
     */
    public function tous(): Response
    {
        // Invocation du modèle pour récupérer les données
        $tousLesArticles = $this->articleService->rechercherTousLesArticles();
        // $articlesDuJour = $articleService->rechercherArticlesDuJour();

        $erreurs = $this->validator->validate($tousLesArticles);
        
        if(count($erreurs) > 0) 
            return new JsonResponse(
                $this->reporter->reportValidationError($erreurs),
                Response::HTTP_BAD_REQUEST,
                []
            );
        
        $tousLesArticlesJSON = $this->serializer->serialize($tousLesArticles, "json");

        return new JsonResponse(
            $tousLesArticlesJSON,
            Response::HTTP_OK,
            [],
            true
        );
    }

    /**
     * @Route(
     *      "/api/article/{id}", 
     *      name="api_article_lire", 
     *      requirements={"id"="\d+"},
     *      methods={"GET"}
     * )
     */
    public function lire($id): Response
    {
        $article = $this->articleService->rechercherArticleParId($id);

        $erreurs = $this->validator->validate($article);
        if(count($erreurs) > 0)
            return new JsonResponse(
                $this->reporter->reportValidationError($erreurs),
                Response::HTTP_BAD_REQUEST,
                []
            );
        
        $articleJSON = $this->serializer->serialize($article, "json");

        return new JsonResponse(
            $articleJSON,
            Response::HTTP_OK,
            [],
            true
        );
    }

    /**
     * @Route(
     *      "/api/article", 
     *      name="api_article_creer",
     *      methods={"POST"}
     * )
     */
    public function creer(Request $request): Response
    {

        $article = $this->serializer->deserialize(
            $request->getContent(),
            Article::class, 
            "json"
        );

        // Définir la valeur par défaut de la date :
        $date = \DateTime::createFromFormat("Y-m-d H:i:s", date("Y-m-d H:i:s"));
        $article->setDatePublication($date);

        $erreurs = $this->validator->validate($article);
        if(count($erreurs) > 0)
            return new JsonResponse(
                $this->reporter->reportValidationError($erreurs),
                Response::HTTP_BAD_REQUEST,
                []
            );

        // On ajoute l'article qui à été alimenté avec les données du formulaire !
        $this->articleService->ajouterArticle($article);

        $articleJSON = $this->serializer->serialize($article, "json");

        return new JsonResponse(
            $articleJSON,
            Response::HTTP_OK,
            ['Location' => $this->generateUrl('api_article_lire', ['id' => $article->getId()])],
            true
        );
    }

    /**
     * @Route(
     *     "/api/article",
     *     name="api_article_modifier",
     *     methods={"PUT"}
     * )
     */
    public function modifier(Request $request): Response
    {
        $article = $this->serializer->deserialize(
            $request->getContent(),
            Article::class, 
            "json"
        );

        $erreurs = $this->validator->validate($article);
        if(count($erreurs) > 0)
            return new JsonResponse(
                $this->reporter->reportValidationError($erreurs),
                Response::HTTP_BAD_REQUEST,
                []
            );
        
        $this->articleService->modifierArticle($article);

        $articleJSON = $this->serializer->serialize($article, "json");

        return new JsonResponse(
            $articleJSON,
            Response::HTTP_OK,
            ['Location' => $this->generateUrl('api_article_lire', ['id' => $article->getId()])],
            true
        );
    }

    /**
     * @Route(
     *      "/api/article/{id}", 
     *      name="api_article_supprimer", 
     *      requirements={"id"="\d+"},
     *      methods={"DELETE"}
     * )
     */
    public function supprimer($id): Response
    {
        $this->articleService->supprimerArticle($id);

        return new JsonResponse(
            "{'message' : 'Article supprim�'}",
            Response::HTTP_OK,
            ['Location' => $this->generateUrl('api_article_tous')],
            true
        );
    }
}
