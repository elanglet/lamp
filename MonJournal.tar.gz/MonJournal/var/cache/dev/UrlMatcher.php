<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/article/tous' => [[['_route' => 'article_tous', '_controller' => 'App\\Controller\\ArticleController::tous'], null, null, null, false, false, null]],
        '/article/creer' => [[['_route' => 'article_creer', '_controller' => 'App\\Controller\\ArticleController::creer'], null, null, null, false, false, null]],
        '/api/articles' => [[['_route' => 'api_article_tous', '_controller' => 'App\\Controller\\ArticleRestController::tous'], null, ['GET' => 0], null, false, false, null]],
        '/api/article' => [
            [['_route' => 'api_article_creer', '_controller' => 'App\\Controller\\ArticleRestController::creer'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'api_article_modifier', '_controller' => 'App\\Controller\\ArticleRestController::modifier'], null, ['PUT' => 0], null, false, false, null],
        ],
        '/auteur/tous' => [[['_route' => 'auteur_tous', '_controller' => 'App\\Controller\\AuteurController::tous'], null, null, null, false, false, null]],
        '/auteur/creer' => [[['_route' => 'auteur_creer', '_controller' => 'App\\Controller\\AuteurController::creer'], null, null, null, false, false, null]],
        '/' => [[['_route' => 'accueil', '_controller' => 'App\\Controller\\IndexController::index'], null, null, null, false, false, null]],
        '/login' => [[['_route' => 'login', '_controller' => 'App\\Controller\\LoginController::index'], null, null, null, false, false, null]],
        '/login_check' => [[['_route' => 'login_check'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/a(?'
                    .'|rticle/(?'
                        .'|lire/(\\d+)(*:194)'
                        .'|modifier/(\\d+)(*:216)'
                        .'|supprimer/(\\d+)(*:239)'
                    .')'
                    .'|pi/article/(\\d+)(?'
                        .'|(*:267)'
                    .')'
                    .'|uteur/(?'
                        .'|modifier/([^/]++)(*:302)'
                        .'|afficher/([^/]++)(*:327)'
                    .')'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        194 => [[['_route' => 'article_lire', '_controller' => 'App\\Controller\\ArticleController::lire'], ['id'], null, null, false, true, null]],
        216 => [[['_route' => 'article_modifier', '_controller' => 'App\\Controller\\ArticleController::modifier'], ['id'], null, null, false, true, null]],
        239 => [[['_route' => 'article_supprimer', '_controller' => 'App\\Controller\\ArticleController::supprimer'], ['id'], null, null, false, true, null]],
        267 => [
            [['_route' => 'api_article_lire', '_controller' => 'App\\Controller\\ArticleRestController::lire'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'api_article_supprimer', '_controller' => 'App\\Controller\\ArticleRestController::supprimer'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        302 => [[['_route' => 'auteur_modifier', '_controller' => 'App\\Controller\\AuteurController::modifier'], ['identifiant'], null, null, false, true, null]],
        327 => [
            [['_route' => 'auteur_afficher', '_controller' => 'App\\Controller\\AuteurController::afficher'], ['identifiant'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
