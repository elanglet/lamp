<?php


namespace App\Model;


use App\Entity\Article;
use Doctrine\ORM\EntityManagerInterface;

class ArticleService
{
    // Attribut qui référence l'EntityManager de Doctrine
    private $em;

    // Constructeur qui va recevoir par injection l'EntityManager de Doctrine
    // Le type 'EntityManagerInterface' permet à Symfony de savoir quel objet injecter !
    public function __construct(EntityManagerInterface $em)
    {
        $this->em = $em;
    }

    public function ajouterArticle(Article $article) {
        try {
            $this->em->persist($article);
            $this->em->flush();
        }
        catch(\Exception $e) {
            // Journaliser l'erreur technique...

            // Générer une exception avec un message fonctionnel...
            throw new \Exception("Erreur lors de l'enregistrement de l'article.", null, $e);
        }
    }

    public function modifierArticle(Article $article) {
        try {

            // $art = $this->em->getRepository('App:Article')->find($article->getId());
            // if($art != null) {
            //     $auteur = $art->getAuteur();
            //     $article->setAuteur($auteur);

            //     $this->em->get

            //     die(print_r($article, true));

            //     $this->em->persist($article);
            //     $this->em->flush();
            // }
            // else {
            //     throw new \Exception("Article introuvable !");
            // }
            $this->em->merge($article);
            $this->em->flush();
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur lors de la mise à jour de l'article.", null, $e);
        }
    }

    public function supprimerArticle(int $id) {
        try {// On récupère l'article par son id grace au repository
            $repo = $this->em->getRepository('App:Article');
            $article = $repo->find($id);
            $this->em->remove($article);
            $this->em->flush();
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur lors de la suppression de l'article.", null, $e);
        }
    }

    public function rechercherTousLesArticles() {
        try {
            return $this->em->getRepository('App:Article')
                ->findAll();
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur de récupération de la liste des articles.", null, $e);
        }
    }

    public function rechercherArticleParId(int $id) {
        try {
            return $this->em->getRepository('App:Article')
                ->find($id);
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur de récupération de l'article d'id $id.", null, $e);
        }
    }

    public function rechercherArticlesDuJour() {
        try {
            return $this->em->getRepository('App:Article')
                ->findTodayDQL();//return $this->em->getRepository('App:Article')
            //    ->findTodayQB();
        }
        catch (\Exception $e) {
            throw new \Exception("Erreur de récupération des articles du jour.", null, $e);
        }
    }
}















